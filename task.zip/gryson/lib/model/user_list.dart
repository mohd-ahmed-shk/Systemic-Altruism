import 'package:gryson/model/user_model.dart';

List<UserModel> userList = [
  UserModel("Ahmed", "a@gmail.com", "22", "5256784125", "Mumbai", "B.Tech", "MP","Male","assets/images/img.jpg"),
  UserModel("Bharat", "bharat@gmail.com", "35", "5846784125", "Indore", "B.Tech", "UP","Female","assets/images/images.jpg"),
  UserModel("Mohan", "mohan@gmail.com", "45", "8956741235", "Bhopal", "BSc", "Maharashtra","Male","assets/images/img.jpg"),


  UserModel("Ahmed", "a@gmail.com", "22", "5256784125", "Mumbai", "B.Tech", "MP","Male","assets/images/img.jpg"),
  UserModel("Bharat", "bharat@gmail.com", "35", "5846784125", "Indore", "B.Tech", "UP","Female","assets/images/images.jpg"),
  UserModel("Mohan", "mohan@gmail.com", "45", "8956741235", "Bhopal", "BSc", "Maharashtra","Male","assets/images/img.jpg"),

  UserModel("Ahmed", "a@gmail.com", "22", "5256784125", "Mumbai", "B.Tech", "MP","Male","assets/images/img.jpg"),
  UserModel("Bharat", "bharat@gmail.com", "35", "5846784125", "Indore", "B.Tech", "UP","Female","assets/images/images.jpg"),
  UserModel("Mohan", "mohan@gmail.com", "45", "8956741235", "Bhopal", "BSc", "Maharashtra","Male","assets/images/img.jpg"),

  UserModel("Ahmed", "a@gmail.com", "22", "5256784125", "Mumbai", "B.Tech", "MP","Male","assets/images/img.jpg"),
  UserModel("Bharat", "bharat@gmail.com", "35", "5846784125", "Indore", "B.Tech", "UP","Female","assets/images/images.jpg"),
  UserModel("Mohan", "mohan@gmail.com", "45", "8956741235", "Bhopal", "BSc", "Maharashtra","Male","assets/images/img.jpg"),

  UserModel("Ahmed", "a@gmail.com", "22", "5256784125", "Mumbai", "B.Tech", "MP","Male","assets/images/img.jpg"),
  UserModel("Bharat", "bharat@gmail.com", "35", "5846784125", "Indore", "B.Tech", "UP","Female","assets/images/images.jpg"),
  UserModel("Mohan", "mohan@gmail.com", "45", "8956741235", "Bhopal", "BSc", "Maharashtra","Male","assets/images/img.jpg"),

  UserModel("Ahmed", "a@gmail.com", "22", "5256784125", "Mumbai", "B.Tech", "MP","Male","assets/images/img.jpg"),
  UserModel("Bharat", "bharat@gmail.com", "35", "5846784125", "Indore", "B.Tech", "UP","Female","assets/images/images.jpg"),
  UserModel("Mohan", "mohan@gmail.com", "45", "8956741235", "Bhopal", "BSc", "Maharashtra","Male","assets/images/img.jpg"),

];